﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fachada
{
    public class Aire
    {
        public void Apagar()
        {
            Console.WriteLine("Aire acondicionado apagado");
        }

        public void Prender()
        {
            Console.WriteLine("Aire acondicionado prendido");
        }

    }
}
