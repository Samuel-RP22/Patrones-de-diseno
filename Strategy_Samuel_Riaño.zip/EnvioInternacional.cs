﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public class EnvioInternacional : IEstrategiaEnvio
    {
        public double CalcularCosto(Pedido pedido)
        {
            double costoBase = 15000;
            double costoPorPeso = pedido.Peso * 3000;
            double costoPorDistancia = pedido.Distancia * 200;
            double seguroAduanero = pedido.ValorDeclarado * 0.05;

            return costoBase + costoPorPeso + costoPorDistancia + seguroAduanero;
        }
    }
}
