﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Builder
{
    interface IBuilder  // interface el que me define el contrato
    {
        void SetCpu();  // contruye la primera parte del producto , que es el cpu
        void SetRam(); // la segunda parte que seria la RAM 
        void SetTarjetaGrafica();
        void SetSistemaOperativo();
        Computadora GetResultado();   //Esto devuelve el producto final 
    }
}
