﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public class EnvioSeguro : IEstrategiaEnvio
    {
        public double CalcularCosto(Pedido pedido)
        {
            double costoBase = 7000;
            double costoPorPeso = pedido.Peso * 1000;
            double recargoSeguro = 2000;
            return costoBase + costoPorPeso + recargoSeguro;
        }
    }
}
