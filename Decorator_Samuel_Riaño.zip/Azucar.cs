﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Azucar : Decorador
    {
        public Azucar(Bebida b) : base(b) { }

        public override string getDescripcion()
        {
            return bebida.getDescripcion() + " + azucar";
        }

        public override double costo()
        {
            return bebida.costo() + 0.5;
        }
    }
}
