﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public class EnvioGratis : IEstrategiaEnvio
    {
        public double CalcularCosto(Pedido pedido)
        {
            if (pedido.ValorDeclarado >= 400000)
                return 0;
            else
            {
                double costoBase = 5000;
                double costoPorPeso = pedido.Peso * 1000;
                return costoBase + costoPorPeso;
            }
        }
    }
}
