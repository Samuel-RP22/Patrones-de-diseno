﻿using System;

namespace SistemaVacaciones
{
    public class Supervisor : JefeBase
    {
        public override void Revisar(Solicitud pedido)
        {
            if (pedido.Dias <= 2)
                Console.WriteLine($"[Supervisor] Yo apruebo los {pedido.Dias} días de {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else if (pedido.Dias <= 5 && pedido.Tipo == "Urgente")
                Console.WriteLine($"[Supervisor] Yo apruebo los {pedido.Dias} días de {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else if (SiguienteJefe != null)
                SiguienteJefe.Revisar(pedido);
        }
    }
}