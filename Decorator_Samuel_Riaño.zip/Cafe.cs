﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Cafe : Bebida
    {
        public override string getDescripcion()
        {
            return "Cafe";
        }

        public override double costo()
        {
            return 5.0;
        }
    }
}
