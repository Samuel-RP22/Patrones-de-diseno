﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fachada
{
    public class Sonido
    {
        public void Apagar()
        {
            Console.WriteLine("Sistema de sonido apagado");
        }

        public void Encender()
        {
            Console.WriteLine("Sistema de sonido sonando correctamente");
        }

    }
}
