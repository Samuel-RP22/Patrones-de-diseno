﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Aromatica : Bebida
    {
        public override string getDescripcion()
        {
            return "Aromatica";
        }

        public override double costo()
        {
            return 4.0;
        }
    }
}
