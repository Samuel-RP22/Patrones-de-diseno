﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Netflix
{
    public class NetflixReal : IStreaming
    {
        private string contenido;

        private int edadMinima;

        private int dispositivosActivos;

        public NetflixReal(string contenido, int edadMinima, int dispositivosActivos)
        {
            this.contenido = contenido;
            this.edadMinima = edadMinima;
            this.dispositivosActivos = dispositivosActivos;
            CargarContenido();
        }

        private void CargarContenido()
        {
            Console.WriteLine("Cargando contenido: " + contenido);
        }

        public void VerContenido()
        {
            Console.WriteLine("Reproduciendo: " + contenido);
        }
    }
}
