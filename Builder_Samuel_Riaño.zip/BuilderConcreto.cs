﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Builder
{
    class BuilderConcreto : IBuilder   //esta clase implementa la interfaz Ibuilder
    {
        private Computadora computadora; //El private se utiliza porque solo el builder la puede modificar
                                         //Aqui se guarda la computadora que se esta construyendo
        public BuilderConcreto()     //constructor de la clase 
        {
            computadora = new Computadora();  //se crea la nueva computadora vacia
        }

        public void SetCpu()   //implementa el metodo de la interfaz
        {                          //Y se construye una parte del producto que seria la cpu
            computadora.CPU = "Intel i7";  //asigna el valor de la CPU
        }

        public void SetRam() //Aqui se construye la otra parte , la RAM
        {
            computadora.RAM = "16GB";  // Asigna valor a la RAM
        }

        public void SetTarjetaGrafica()
        {
            computadora.Interfaz = "GeForce RTX 4090 ";  
        }
        public void SetSistemaOperativo()
        {
            computadora.SO = "Windows 11 Pro";
        }


        public Computadora GetResultado()
        {
            return computadora;    //Devuelve el producto
        }
    }
}
