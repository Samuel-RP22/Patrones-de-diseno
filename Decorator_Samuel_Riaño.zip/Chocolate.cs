﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Chocolate : Decorador
    {
        public Chocolate(Bebida b) : base(b) { }

        public override string getDescripcion()
        {
            return bebida.getDescripcion() + " + chocolate";
        }

        public override double costo()
        {
            return bebida.costo() + 3.0;
        }
    }
}
