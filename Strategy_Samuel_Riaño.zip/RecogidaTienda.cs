﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public class RecogidaEnTienda : IEstrategiaEnvio
    {
        public double CalcularCosto(Pedido pedido)
        {
            return 0;
        }
    }
}
