﻿using System;

namespace SistemaVacaciones
{
    public class Gerente : JefeBase
    {
        public override void Revisar(Solicitud pedido)
        {
            if (pedido.Dias <= 7)
                Console.WriteLine($"[Gerente] Permiso de {pedido.Dias} días para {pedido.Empleado} concedido por excusa: '{pedido.Tipo}'");
            else if (pedido.Dias <= 10 && pedido.Tipo == "Medica")
                Console.WriteLine($"[Recursos Humanos] Yo apruebo los {pedido.Dias} días de {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else if (pedido.Dias <= 15 && pedido.Tipo == "Urgente")
                Console.WriteLine($"[Supervisor] Yo apruebo los {pedido.Dias} días de {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else if (SiguienteJefe != null)
                SiguienteJefe.Revisar(pedido);
        }
    }
}