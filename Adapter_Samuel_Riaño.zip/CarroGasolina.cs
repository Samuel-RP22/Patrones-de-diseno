﻿using System;
using System.Collections.Generic;
using System.Text;
using TallerMotosAdapter;

namespace TallerMecanico
{
    public class CarroGasolina : IMantenimiento
    {
        public string Placa { get; set; }
        public string Marca { get; set; }

        public CarroGasolina(string placa, string marca)
        {
            Placa = placa;
            Marca = marca;
        }

        public void RealizarMantenimiento()
        {
            Console.WriteLine($"- [Carro {Marca} - {Placa}]: Cambiando aceite, revisando bujías y carburador.");
            Console.WriteLine($"- [Carro {Marca} - {Placa}]: Presurizando y organizando las llantas");
        }
    }
}
