﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    abstract class Decorador : Bebida
    {
        protected Bebida bebida;

        public Decorador(Bebida b)
        {
            bebida = b;
        }
    }
}
