﻿using Fachada;
using System;

CineFacade cine = new CineFacade();

Console.WriteLine("Iniciando pelicula: \n\n");
cine.VerPelicula();

Console.WriteLine("\n\nPresione una tecla para terminar...");
Console.ReadKey();

Console.WriteLine("\n");
cine.TerminarPelicula();
