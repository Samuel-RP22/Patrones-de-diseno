﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Cocoa : Decorador
    {
        public Cocoa(Bebida b) : base(b) { }

        public override string getDescripcion()
        {
            return bebida.getDescripcion() + " + cococa";
        }

        public override double costo()
        {
            return bebida.costo() + 3.0;
        }
    }
}
