﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public class Pedido
    {
        public double Peso { get; set; }
        public double Distancia { get; set; }
        public double ValorDeclarado { get; set; }

        public Pedido(double peso, double distancia, double valorDeclarado)
        {
            Peso = peso;
            Distancia = distancia;
            ValorDeclarado = valorDeclarado;
        }
    }
}

