﻿using Netflix;

class Program
{
    static void Main()
    {
        IStreaming usuario1 = new ProxyNetflix("Stranger Things", 20, 1, true, true);
        usuario1.VerContenido();

        Console.WriteLine();

        IStreaming usuario2 = new ProxyNetflix("Breaking Bad", 16, 1, true, true);
        usuario2.VerContenido();

        Console.WriteLine();

        IStreaming usuario3 = new ProxyNetflix("Dark", 22, 2, true, true);
        usuario3.VerContenido();

        Console.WriteLine();

        IStreaming usuario4 = new ProxyNetflix("Peaky Blinders", 25, 1, false, true);
        usuario4.VerContenido();

        Console.WriteLine();

        IStreaming usuario5 = new ProxyNetflix("Narcos", 30, 1, true, false);
        usuario5.VerContenido();

        Console.WriteLine();

        IStreaming usuario6 = new ProxyNetflix("The Witcher", 18, 0, true, true);
        usuario6.VerContenido();

        Console.WriteLine();

        IStreaming usuario7 = new ProxyNetflix("Black Mirror", 40, 3, false, false);
        usuario7.VerContenido();
    }
}