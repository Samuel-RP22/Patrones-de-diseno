﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public class EnvioNormal : IEstrategiaEnvio
    {
        public double CalcularCosto(Pedido pedido)
        {
            double costoBase = 5000;
            double costoPorPeso = pedido.Peso * 1000;

            return costoBase + costoPorPeso;
        }
    }
}
