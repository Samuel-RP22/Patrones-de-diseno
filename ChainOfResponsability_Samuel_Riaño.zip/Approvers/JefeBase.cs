﻿namespace SistemaVacaciones
{
    public abstract class JefeBase
    {
        protected JefeBase SiguienteJefe;

        public void AsignarSiguiente(JefeBase siguiente)
        {
            SiguienteJefe = siguiente;
        }

        public abstract void Revisar(Solicitud pedido);
    }
}