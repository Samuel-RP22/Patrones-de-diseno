﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Te : Bebida
    {
        public override string getDescripcion()
        {
            return "Te";
        }

        public override double costo()
        {
            return 4.0;
        }
    }
}
