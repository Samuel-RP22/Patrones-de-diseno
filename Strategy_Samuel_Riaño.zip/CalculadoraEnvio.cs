﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Context del patrón Strategy.
namespace Ejemplo2StrategyEnvios

{
    public class CalculadoraEnvio
    {
        private IEstrategiaEnvio estrategiaEnvio;

        public CalculadoraEnvio(IEstrategiaEnvio estrategiaEnvio)
        {
            this.estrategiaEnvio = estrategiaEnvio;
        }

        public void CambiarEstrategia(IEstrategiaEnvio nuevaEstrategia)
        {
            estrategiaEnvio = nuevaEstrategia;
        }

        public double ObtenerCostoEnvio(Pedido pedido)
        {
            return estrategiaEnvio.CalcularCosto(pedido);
        }
    }
}
