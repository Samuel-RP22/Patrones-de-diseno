﻿using Ejemplo2StrategyEnvios;


Pedido pedido = new Pedido(2.5, 10, 500000);

CalculadoraEnvio calculadora = new CalculadoraEnvio(new EnvioNormal());

Console.WriteLine("=== CÁLCULO DE COSTOS DE ENVÍO ===");
Console.WriteLine("Peso del pedido: " + pedido.Peso + " kg");
Console.WriteLine("Distancia: " + pedido.Distancia + " km"); 
Console.WriteLine("Valor declarado: $" + pedido.ValorDeclarado);
Console.WriteLine();

double costoNormal = calculadora.ObtenerCostoEnvio(pedido);
Console.WriteLine("Costo con envío normal: $" + costoNormal);

calculadora.CambiarEstrategia(new EnvioExpress());
 double costoExpress = calculadora.ObtenerCostoEnvio(pedido);
Console.WriteLine("Costo con envío express: $" + costoExpress);

calculadora.CambiarEstrategia(new EnvioInternacional());
double costoInternacional = calculadora.ObtenerCostoEnvio(pedido);
Console.WriteLine("Costo con envío internacional: $" + costoInternacional);

calculadora.CambiarEstrategia(new EnvioGratis());
double EnvioGratis = calculadora.ObtenerCostoEnvio(pedido);
if (EnvioGratis == 0)
    Console.WriteLine("Costo con envío gratis: ¡¡Tu envio es gratis!!");
else
{
    Console.WriteLine("Costo con envío gratis: $" + EnvioGratis + " (Tu envío no es gratis, tu compra debe ser mayor a 400.000)");
}

calculadora.CambiarEstrategia(new EnvioSeguro());
double EnvioSeguro = calculadora.ObtenerCostoEnvio(pedido);
Console.WriteLine("Costo con seguro premium: $" + EnvioSeguro);

calculadora.CambiarEstrategia(new RecogidaEnTienda());
double RecogidaEnTienda = calculadora.ObtenerCostoEnvio(pedido);
Console.WriteLine("Costo por recoger en tienda: $" + RecogidaEnTienda);


