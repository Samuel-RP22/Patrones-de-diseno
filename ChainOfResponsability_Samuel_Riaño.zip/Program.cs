﻿using System;

namespace SistemaVacaciones
{
    class Program
    {
        static void Main()
        {
            // Creamos los objetos de los jefes
            var supervisor = new Supervisor();
            var gerente = new Gerente();
            var director = new Director();
            var coordinador = new Coordinador();
            var recursosHumanos = new RecursosHumanos();

            // Los encadenamos: el super le pasa al gerente, el gerente al director
            supervisor.AsignarSiguiente(coordinador);
            coordinador.AsignarSiguiente(gerente);
            gerente.AsignarSiguiente(recursosHumanos);
            recursosHumanos.AsignarSiguiente(director);

            // Lista de pruebas
            var lista = new[]
            {
                new Solicitud("Ana", 1, "Normal"),
                new Solicitud("Luis", 4, "Urgente"),
                new Solicitud("María", 5, "Normal"),
                new Solicitud("Carlos", 9, "Urgente"),
                new Solicitud("Pedro", 7, "Vacaciones"),
                new Solicitud("Laura", 10, "Medica"),
                new Solicitud("Camila", 15, "Medica"),
                new Solicitud("Jorge", 25, "Vacaciones"),
                new Solicitud("Sofía", 30, "Normal"),
                new Solicitud("Andrés", 45, "Vacaciones")
            };

            Console.WriteLine("--- SISTEMA DE GESTIÓN DE PERMISOS ---");
            foreach (var s in lista)
            {
                supervisor.Revisar(s);
            }

            Console.WriteLine("\nPresione cualquier tecla...");
            Console.ReadKey();
        }
    }
}