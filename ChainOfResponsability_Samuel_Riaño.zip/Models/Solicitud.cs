﻿namespace SistemaVacaciones
{
    // Clase simple para los datos que pide el empleado
    public class Solicitud
    {
        public string Empleado { get; set; }
        public int Dias { get; set; }
        public string Tipo { get; set; }

        public Solicitud(string nombre, int cantidad, string tipo)
        {
            Empleado = nombre;
            Dias = cantidad;
            Tipo = tipo;
        }
    }
}