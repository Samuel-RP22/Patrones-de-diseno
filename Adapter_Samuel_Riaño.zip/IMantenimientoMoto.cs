﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TallerMotosAdapter
{
    public interface IMantenimiento
    {
        void RealizarMantenimiento();
    }
}