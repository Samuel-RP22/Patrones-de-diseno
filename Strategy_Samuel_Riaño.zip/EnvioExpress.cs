﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public class EnvioExpress : IEstrategiaEnvio
    {
        public double CalcularCosto(Pedido pedido)
        {
            double costoBase = 8000;
            double costoPorPeso = pedido.Peso * 1500;
            double recargoRapidez = 4000;

            return costoBase + costoPorPeso + recargoRapidez;
        }
    }
}
