﻿using System;

namespace SistemaVacaciones
{
    public class Director : JefeBase
    {
        public override void Revisar(Solicitud pedido)
        {
            if (pedido.Dias <= 30)
                Console.WriteLine($"[Director] Autorizo la licencia larga de {pedido.Dias} días a {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else
                Console.WriteLine($"[AVISO] {pedido.Empleado} pide demasiados días ({pedido.Dias}). No se puede aprobar.");
        }
    }
}