﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TallerMecanico
{
    public class CarroElectrico
    {
        public string Placa { get; set; }
        public float NivelBateria { get; set; }

        public CarroElectrico(string placa, float bateria)
        {
            Placa = placa;
            NivelBateria = bateria;
        }

        public void DiagnosticarBateria()
        {
            Console.WriteLine($"- [Carro Eléctrica {Placa}]: Escaneando batería. Nivel al {NivelBateria}%.");
        }

        public void ActualizarFirmware()
        {
            Console.WriteLine($"- [Carro Eléctrica {Placa}]: Instalando actualización de software del motor.");
        }

        public void MantenimientoLLantas()
        {
            Console.WriteLine($"- [Carro Eléctrico {Placa}]: Presurizando y organizando las llantas");
        }
    }
}