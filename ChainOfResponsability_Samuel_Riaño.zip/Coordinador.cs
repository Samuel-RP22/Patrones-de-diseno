﻿using System;

namespace SistemaVacaciones
{
    public class Coordinador : JefeBase
    {
        public override void Revisar(Solicitud pedido)
        {
            if (pedido.Dias <= 5)
                Console.WriteLine($"[Coordinador] Yo apruebo los {pedido.Dias} días de {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else if (pedido.Dias <= 10 && pedido.Tipo == "Urgente")
                Console.WriteLine($"[Supervisor] Yo apruebo los {pedido.Dias} días de {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else if (SiguienteJefe != null)
                SiguienteJefe.Revisar(pedido);
        }
    }
}
