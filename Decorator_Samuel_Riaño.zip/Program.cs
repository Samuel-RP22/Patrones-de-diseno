﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Decorator;

Bebida bebida = null;

Console.WriteLine("Seleccione una bebida:");
Console.WriteLine("1. Cafe ($5)");
Console.WriteLine("2. Te ($4)");
Console.WriteLine("3. Aromatica ($4)");
Console.Write("Opcion: ");
int opcion = int.Parse(Console.ReadLine());

if (opcion == 1)
    bebida = new Cafe();
else if (opcion == 2)
    bebida = new Te();
else if (opcion == 3)
    bebida = new Aromatica();
else
{
    Console.WriteLine("Opcion invalida");
    return;
}

Console.WriteLine("\nSeleccione las adiciones que desee (separadas por coma):");
Console.WriteLine("1. Leche (+$2)");
Console.WriteLine("2. Chocolate (+$3)");
Console.WriteLine("3. Canela (+$1.5)");
Console.WriteLine("4. Cocoa (+$3)");
Console.WriteLine("5. Miel (+$2.5)");
Console.WriteLine("6. Vainilla (+$3)");
Console.WriteLine("7. Azucar (+$0.5)");
Console.Write("Ejemplo: 1,2,3 -> ");

string entrada = Console.ReadLine();
string[] opciones = entrada.Split(',');

foreach (string op in opciones)//se recorre la lista creada
{
    int opAdicion;
    if (int.TryParse(op.Trim(), out opAdicion))// se lee lo ingresado, es un numero y se guarda
    {
        switch (opAdicion)
        {
            case 1:
                bebida = new Leche(bebida);
                break;
            case 2:
                bebida = new Chocolate(bebida);
                break;
            case 3:
                bebida = new Canela(bebida);
                break;
            case 4:
                bebida = new Cocoa(bebida);
                break;
            case 5:
                bebida = new Miel(bebida);
                break;
            case 6:
                bebida = new Vainilla(bebida);
                break;
            case 7:
                bebida = new Azucar(bebida);
                break;
        }
    }
}

Console.WriteLine("\n RESULTADO FINAL ");
Console.WriteLine("Pedido: " + bebida.getDescripcion());
Console.WriteLine("Costo total: $" + bebida.costo());

