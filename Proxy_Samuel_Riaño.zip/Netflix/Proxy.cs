﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Netflix
{
    public class ProxyNetflix(string contenido, int edadMinima, int dispositivosActivos, bool tieneSuscripcion, bool tieneInternet) : IStreaming
    {
        private NetflixReal? netflixReal;
        private string contenido = contenido;
        private int edadMinima = edadMinima;
        private int dispositivosActivos = dispositivosActivos;
        private bool tieneSuscripcion = tieneSuscripcion;
        private bool tieneInternet = tieneInternet;

        public void VerContenido()
        {
            if (!tieneInternet)
            {
                Console.WriteLine("No tienes conexión a internet");
                return;
            }
            if (!tieneSuscripcion)
            {
                Console.WriteLine("No tienes suscripción");
                return;
            }
            if (edadMinima < 18)
            {
                Console.WriteLine("No puedes usar netflix adultos, debes ser mayor de 18 años");
                return;
            }
            if (dispositivosActivos >= 2)
            {
                Console.WriteLine("No puedes usar mas de 1 dispositivo a la vez");
                return;
            }

            if (netflixReal == null)
            {
                netflixReal = new NetflixReal(contenido, edadMinima, dispositivosActivos);
            }

            netflixReal.VerContenido();
        }
    }
}
