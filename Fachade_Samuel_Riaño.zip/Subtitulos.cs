﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fachada
{
    public class Subtitulos
    {
        public void Desactivar()
        {
            Console.WriteLine("Subtitulos desactivados");
        }

        public void Activar()
        {
            Console.WriteLine("Subtitulos activados");
        }

    }
}
