﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Miel : Decorador
    {
        public Miel(Bebida b) : base(b) { }

        public override string getDescripcion()
        {
            return bebida.getDescripcion() + " + miel";
        }

        public override double costo()
        {
            return bebida.costo() + 2.5;
        }
    }
}
