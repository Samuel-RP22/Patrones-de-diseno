﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    class Vainilla : Decorador
    {
        public Vainilla(Bebida b) : base(b) { }

        public override string getDescripcion()
        {
            return bebida.getDescripcion() + " + vainilla";
        }

        public override double costo()
        {
            return bebida.costo() + 3.0;
        }
    }
}
