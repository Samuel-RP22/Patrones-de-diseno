﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    abstract class Bebida
    {
        public abstract string getDescripcion();
        public abstract double costo();
    }
}
