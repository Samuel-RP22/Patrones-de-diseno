﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fachada
{
    public class CineFacade
    {
        private Luces luces;
        private Proyector proyector;
        private Reproductor reproductor;
        private Sonido sonido;
        private Subtitulos subtitulos;
        private Aire aire;

        public CineFacade()
        {
            luces = new Luces();
            proyector = new Proyector();
            reproductor = new Reproductor();
            sonido = new Sonido();
            subtitulos = new Subtitulos();
            aire = new Aire();
        }

        public void VerPelicula()
        {
            aire.Prender();
            luces.Apagar();
            proyector.Encender();
            reproductor.Reproducir();
            sonido.Encender();
            subtitulos.Activar();
        }

        public void TerminarPelicula()
        {
            aire.Apagar();
            reproductor.Detener();
            proyector.Apagar();
            luces.Encender();
            sonido.Apagar();
            subtitulos.Desactivar();
        }
    }
}
