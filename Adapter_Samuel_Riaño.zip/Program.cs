﻿using System;
using TallerMecanico;

namespace TallerMotosAdapter
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("=== TALLER DE MOTOS 'DESBIELADO' ===\n\n");

            AdministradorTaller jefeTaller = new AdministradorTaller("Ernesto");

            //MOTO NORMAL
            Console.WriteLine(">>> INGRESANDO MOTO A GASOLINA:");
            MotoGasolina motoNormal = new MotoGasolina("GZB-06H", "TVS");
            jefeTaller.OrdenarReparacion(motoNormal);

            Console.WriteLine("\n------------------------------------------------");

            //MOTO ELÉCTRICA
            Console.WriteLine(">>> INGRESANDO MOTO ELÉCTRICA:");
            MotoElectrica motoElectrica = new MotoElectrica("UBB-29F", 85.5f);

            AdaptadorMotoElectrica adaptador = new AdaptadorMotoElectrica(motoElectrica);
            jefeTaller.OrdenarReparacion(adaptador);

            Console.WriteLine("\n------------------------------------------------");

            Console.WriteLine(">>> INGRESANDO CARRO A GASOLINA:");
            CarroGasolina carroNormal = new CarroGasolina("LFP-289", "Kia");
            jefeTaller.OrdenarReparacion(carroNormal);

            Console.WriteLine("\n------------------------------------------------");

            Console.WriteLine(">>> INGRESANDO CARRO ELÉCTRICA:");
            CarroElectrico carroElectrico = new CarroElectrico("HYR-900", 75.5f);

            AdaptadorCarroElectrico adapter = new AdaptadorCarroElectrico(carroElectrico);
            jefeTaller.OrdenarReparacion(adapter);

















            Console.ReadLine();
        }
    }
}