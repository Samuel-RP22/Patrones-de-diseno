﻿using System;

namespace SistemaVacaciones
{
    public class RecursosHumanos : JefeBase
    {
        public override void Revisar(Solicitud pedido)
        {
            if (pedido.Dias <= 15 && pedido.Tipo == "Medica")
                Console.WriteLine($"[Recursos Humanos] Yo apruebo los {pedido.Dias} días de {pedido.Empleado} por excusa: '{pedido.Tipo}'");
            else if (SiguienteJefe != null)
                SiguienteJefe.Revisar(pedido);
        }
    }
}