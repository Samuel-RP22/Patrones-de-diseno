﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using TallerMotosAdapter;

namespace TallerMecanico
{
    public class AdaptadorCarroElectrico : IMantenimiento
    {
        private CarroElectrico _carroElectrico;

        public AdaptadorCarroElectrico(CarroElectrico carro)
        {
            _carroElectrico = carro;
        }

        public void RealizarMantenimiento()
        {
            Console.WriteLine(">>> [Adaptador] Interceptando orden y traduciendo a comandos eléctricos...");
            _carroElectrico.DiagnosticarBateria();
            _carroElectrico.ActualizarFirmware();
            _carroElectrico.MantenimientoLLantas();
            Console.WriteLine(">>> [Adaptador] Mantenimiento eléctrico finalizado.");
        }
    }
}