﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2StrategyEnvios
{
    public interface IEstrategiaEnvio
    {
        double CalcularCosto(Pedido pedido);
    }
}
